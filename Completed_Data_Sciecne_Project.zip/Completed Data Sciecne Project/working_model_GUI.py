import os
import nltk
import numpy as np
import pandas as pd
import joblib
from nltk.tokenize import sent_tokenize, word_tokenize
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
from tkinter import messagebox, simpledialog, Tk, Label, Button, OptionMenu
from sklearn.metrics import confusion_matrix
from tkinter import StringVar



# Download the required NLTK packages
nltk.download('punkt')

# Function to extract features from a paragraph
def extract_features(paragraph):
    sentences = sent_tokenize(paragraph)
    words = word_tokenize(paragraph)
    features = {
        "num_sentences": len(sentences),
        "num_words": len(words),
        "presence_parentheses": 1 if "(" in paragraph or ")" in paragraph else 0,
        "presence_dash": 1 if "-" in paragraph else 0,
        "presence_semicolon_colon": 1 if ";" in paragraph or ":" in paragraph else 0,
        "presence_question_mark": 1 if "?" in paragraph else 0,
        "presence_apostrophe": 1 if "'" in paragraph else 0,
        "std_sentence_length": np.std([len(sent) for sent in sentences]),
        "mean_diff_sentence_length": np.mean([abs(len(sentences[i]) - len(sentences[i-1])) 
                                              for i in range(1, len(sentences))]) if len(sentences) > 1 else 0,
        "presence_short_sentences": 1 if any(len(sent) < 11 for sent in sentences) else 0,
        "presence_long_sentences": 1 if any(len(sent) > 34 for sent in sentences) else 0,
        "presence_numbers": 1 if any(char.isdigit() for char in paragraph) else 0,
        "presence_more_capitals": 1 if sum(1 for c in paragraph if c.isupper()) > paragraph.count('.') * 2 else 0,
        "presence_although": 1 if "although" in words else 0,
        "presence_however": 1 if "however" in words else 0,
        "presence_but": 1 if "but" in words else 0,
        "presence_because": 1 if "because" in words else 0,
        "presence_this": 1 if "this" in words else 0,
        "presence_others_researchers": 1 if "others" in words or "researchers" in words else 0,
        "presence_et": 1 if "et" in words else 0
    }
    return features

def extract_paragraphs_from_files(folder):
    paragraphs = []
    # List all files in the directory
    for filename in os.listdir(folder):
        filepath = os.path.join(folder, filename)
        # Check if it is a file
        if os.path.isfile(filepath):
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as file:
                text = file.read()
                # Split text into paragraphs
                paras = text.split('\n\n')
                # Filter out any empty paragraphs
                paras = [para for para in paras if para and not para.isspace()]
                paragraphs.extend(paras)
    return paragraphs

# Extract paragraphs from both folders
gpt_paragraphs = extract_paragraphs_from_files('CowboyChatGPT')
human_paragraphs = extract_paragraphs_from_files('CowboyHuman')

# Label the paragraphs (1 for GPT, 0 for Human)
gpt_labels = [1] * len(gpt_paragraphs)
human_labels = [0] * len(human_paragraphs)

# Combine the paragraphs and labels
paragraphs = gpt_paragraphs + human_paragraphs
labels = gpt_labels + human_labels

# Extract features for each paragraph
features = [extract_features(para) for para in paragraphs]

# Convert the features into a DataFrame
df_features = pd.DataFrame(features)
df_labels = pd.Series(labels)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(df_features, df_labels, test_size=0.2)

def print_dataset_info(X_train, X_test, y_train, y_test):
    print("Features in X_train:", X_train.columns.tolist())
    print("Features in X_test:", X_test.columns.tolist())
    print("Name of y_train:", y_train.name)
    print("Name of y_test:", y_test.name)

# Calling the function with the mock data
print_dataset_info(X_train, X_test, y_train, y_test)

# Initialize and train the XGBoost classifier
xgb_model = XGBClassifier(use_label_encoder=False, eval_metric='logloss')
xgb_model.fit(X_train, y_train)

# Predict on the test set
y_pred = xgb_model.predict(X_test)

# Calculate the accuracy
accuracy = accuracy_score(y_test, y_pred)

# Save the trained model to a file
model_filename = 'xgb_model.joblib'
joblib.dump(xgb_model, model_filename)

# Return the accuracy
print(f"Accuracy: {accuracy * 100:.2f}%")
print_dataset_info(X_train, X_test, y_train, y_test)

# Function to display a GUI popup for Data Quality report
def display_data_quality_report(data, data_type):
    if data_type == 'Categorical Features':
        categorical_data = data.select_dtypes(include='object')
        if not categorical_data.empty:
            report = categorical_data.describe(include='O')  # 'O' for object (categorical)
            messagebox.showinfo("Data Quality Report", f"Data Quality Report for {data_type}:\n\n{report}")
        else:
            messagebox.showinfo("Data Quality Report", f"No categorical features found.")
    else:
        report = data.describe()
        messagebox.showinfo("Data Quality Report", f"Data Quality Report for {data_type}:\n\n{report}")

# Function to display histograms for selected features
def display_histograms(data):
    for feature in data.columns:
        plt.figure(figsize=(8, 6))
        sns.histplot(data[feature].astype(float), bins=20, kde=True)
        plt.title(f'Histogram for {feature}')
        plt.xlabel(feature)
        plt.ylabel('Frequency')
        plt.show()

# Function to display barplots for selected features
def display_barplots(data):
    for feature in data.columns:
        plt.figure(figsize=(8, 6))
        sns.countplot(x=feature, data=pd.DataFrame({feature: data[feature]}))
        plt.title(f'Barplot for {feature}')
        plt.xlabel(feature)
        plt.ylabel('Count')
        plt.show()


# Function to handle the feature selection and display
def handle_feature_selection(feature_var):
    selected_feature = feature_var.get()
    if selected_feature:
        display_histogram(selected_feature)
        display_barplot(selected_feature)
    else:
        messagebox.showinfo("Error", "Please select a feature.")

# GUI for feature selection and display
def feature_display_gui():
    root = Tk()
    root.title("Feature Display GUI")

    feature_var = StringVar()
    features_list = df_features.columns.tolist()

    label = Label(root, text="Select a feature:")
    label.pack()

    feature_menu = OptionMenu(root, feature_var, *features_list)
    feature_menu.pack()

    display_button = Button(root, text="Display", command=lambda: handle_feature_selection(feature_var))
    display_button.pack()

    root.mainloop()


def display_correlation_matrix(data):
    plt.figure(figsize=(10, 8))
    sns.heatmap(data.corr(), annot=True, cmap='coolwarm', fmt=".2f")
    plt.title('Correlation Matrix')
    plt.show()

# Display Data Quality report for categorical features
display_data_quality_report(df_features.select_dtypes(include='object'), 'Categorical Features')

# Display Data Quality report for continuous features
display_data_quality_report(df_features.select_dtypes(include=np.number), 'Continuous Features')

# Display a correlation matrix for features
display_correlation_matrix(df_features)

# Display histograms for features
display_histograms(df_features)

# Display barplots for features
display_barplots(df_features)

# After predicting on the test set
y_pred = xgb_model.predict(X_test)

# Calculate the accuracy
accuracy = accuracy_score(y_test, y_pred)

# Print the accuracy
print(f"Accuracy: {accuracy * 100:.2f}%")

# Print dataset info
print_dataset_info(X_train, X_test, y_train, y_test)

# Plot the confusion matrix
cm = confusion_matrix

# Function to print dataset info and display in a figure
def print_and_display_dataset_info(X_train, X_test, y_train, y_test):
    print("Features in X_train:", X_train.columns.tolist())
    print("Features in X_test:", X_test.columns.tolist())
    print("Name of y_train:", y_train.name)
    print("Name of y_test:", y_test.name)

    # Display in a figure
    plt.figure(figsize=(10, 6))
    plt.text(0.1, 0.9, f"Features in X_train: {X_train.columns.tolist()}", fontsize=10)
    plt.text(0.1, 0.8, f"Features in X_test: {X_test.columns.tolist()}", fontsize=10)
    plt.text(0.1, 0.7, f"Name of y_train: {y_train.name}", fontsize=10)
    plt.text(0.1, 0.6, f"Name of y_test: {y_test.name}", fontsize=10)
    plt.axis('off')  # Turn off axis
    plt.show()

# Calling the function with the mock data
print_and_display_dataset_info(X_train, X_test, y_train, y_test)


# Open the GUI for feature selection and display
#feature_display_gui()
