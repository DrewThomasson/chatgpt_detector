import joblib
import pandas as pd
import numpy as np
from nltk.tokenize import sent_tokenize, word_tokenize
import os

# Function to extract features from a paragraph
def extract_features(paragraph):
    sentences = sent_tokenize(paragraph)
    words = word_tokenize(paragraph)
    features = {
        "num_sentences": len(sentences),
        "num_words": len(words),
        "presence_parentheses": 1 if "(" in paragraph or ")" in paragraph else 0,
        "presence_dash": 1 if "-" in paragraph else 0,
        "presence_semicolon_colon": 1 if ";" in paragraph or ":" in paragraph else 0,
        "presence_question_mark": 1 if "?" in paragraph else 0,
        "presence_apostrophe": 1 if "'" in paragraph else 0,
        "std_sentence_length": np.std([len(sent) for sent in sentences]),
        "mean_diff_sentence_length": np.mean([abs(len(sentences[i]) - len(sentences[i-1])) 
                                              for i in range(1, len(sentences))]) if len(sentences) > 1 else 0,
        "presence_short_sentences": 1 if any(len(sent) < 11 for sent in sentences) else 0,
        "presence_long_sentences": 1 if any(len(sent) > 34 for sent in sentences) else 0,
        "presence_numbers": 1 if any(char.isdigit() for char in paragraph) else 0,
        "presence_more_capitals": 1 if sum(1 for c in paragraph if c.isupper()) > paragraph.count('.') * 2 else 0,
        "presence_although": 1 if "although" in words else 0,
        "presence_however": 1 if "however" in words else 0,
        "presence_but": 1 if "but" in words else 0,
        "presence_because": 1 if "because" in words else 0,
        "presence_this": 1 if "this" in words else 0,
        "presence_others_researchers": 1 if "others" in words or "researchers" in words else 0,
        "presence_et": 1 if "et" in words else 0
    }
    return features

def predict_paper_with_prob(model, test_paper):
    # Extract features for the paper
    paper_features = extract_features(test_paper)

    # Convert features into a DataFrame
    paper_df = pd.DataFrame([paper_features])

    # Use the trained model to predict probabilities
    proba = model.predict_proba(paper_df)[0]

    # Use the trained model to predict the class
    prediction = model.predict(paper_df)[0]

    return prediction, proba

def predict_papers_in_folder(model, folder_path):
    predictions = []
    confidences = []

    # Iterate through all files in the folder
    for filename in os.listdir(folder_path):
        if filename.endswith(".txt"):
            file_path = os.path.join(folder_path, filename)

            # Read the content of the text file
            with open(file_path, 'r', encoding='utf-8') as file:
                test_input_paper = file.read()

            # Predict using the loaded model
            prediction, confidence = predict_paper_with_prob(model, test_input_paper)

            # Store results for this file
            predictions.append(prediction)
            confidences.append(confidence)

            # Display the results for this file
            print(f"File: {filename}")
            if prediction == 1:
                print("Prediction: GPT generated")
                print(f"Confidence: {confidence[1]}")
            else:
                print("Prediction: Human generated")
                print(f"Confidence: {confidence[0]}")
            print("\n" + "=" * 30 + "\n")

    return predictions, confidences

if __name__ == "__main__":
    # Load the trained model
    loaded_model = joblib.load('xgb_model.joblib')

    # Specify the folder containing test papers
    test_papers_folder = 'Testing Papers'

    # Predict papers in the folder
    all_predictions, all_confidences = predict_papers_in_folder(loaded_model, test_papers_folder)

    # Optionally, you can use all_predictions and all_confidences for further analysis or reporting.
